### Controles ###
* Right Control : Afficher les bodies
* Fl�che du haut : Sauter
* Fl�che du bas : S'accroupir !
* Fl�che de droite : Sauter � droite
* Fl�che de gauche : Sauter � gauche

### Si le fichier JAR ne se lance pas ###
* Mettre � jour le JRE
* Si l'ordinateur dispose de deux cartes graphiques (NVidia optimus), essayer de changer les param�tres de Nvidia de fa�on
	� lancer javaw.exe sur la Nvidia et si �a ne marche toujours pas, essayer sur l'intel integr�e.
* Lancer le fichier JAR depuis l'invite de commandes : 'java -jar TheEndlessCastle.jar 2>> log.txt' et regarder le fichier log.txt g�n�r�.